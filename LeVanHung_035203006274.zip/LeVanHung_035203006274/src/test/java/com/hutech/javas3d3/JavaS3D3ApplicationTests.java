package com.hutech.javas3d3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaS3D3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
