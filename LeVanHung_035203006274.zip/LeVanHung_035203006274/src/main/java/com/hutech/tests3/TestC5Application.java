package com.hutech.tests3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestC5Application {

    public static void main(String[] args) {
        SpringApplication.run(TestC5Application.class, args);
    }

}
